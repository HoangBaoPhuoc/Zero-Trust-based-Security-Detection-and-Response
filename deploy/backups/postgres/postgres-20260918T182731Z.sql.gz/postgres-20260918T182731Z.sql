--
-- PostgreSQL database dump
--

\restrict Cla6iqfacnsQy1dZ2XwsUlbZwp2fXmf8MlgNQMUE314pxYHGJlEDHHf8eMKbupQ

-- Dumped from database version 14.24 (Debian 14.24-1.pgdg13+2)
-- Dumped by pg_dump version 14.24 (Debian 14.24-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.service_request DROP CONSTRAINT IF EXISTS service_request_vehicle_id_40144b75_fk_vehicle_details_id;
ALTER TABLE IF EXISTS ONLY public.service_request DROP CONSTRAINT IF EXISTS service_request_mechanic_id_2188b81f_fk_mechanic_id;
ALTER TABLE IF EXISTS ONLY public.service_comment DROP CONSTRAINT IF EXISTS service_comment_service_request_id_e2867c1a_fk_service_r;
ALTER TABLE IF EXISTS ONLY public."order" DROP CONSTRAINT IF EXISTS order_user_id_e323497c_fk_user_login_id;
ALTER TABLE IF EXISTS ONLY public."order" DROP CONSTRAINT IF EXISTS order_product_id_5feb8b6f_fk_product_id;
ALTER TABLE IF EXISTS ONLY public.mechanic DROP CONSTRAINT IF EXISTS mechanic_user_id_2d21c908_fk_user_login_id;
ALTER TABLE IF EXISTS ONLY public.vehicle_details DROP CONSTRAINT IF EXISTS fko56hs6spaqghjao74nxo722d9;
ALTER TABLE IF EXISTS ONLY public.vehicle_details DROP CONSTRAINT IF EXISTS fkhddm1k427ctferv7q18yw8g2l;
ALTER TABLE IF EXISTS ONLY public.otp_token DROP CONSTRAINT IF EXISTS fkfg4vifvm6fphhv4o1r9vkj7k4;
ALTER TABLE IF EXISTS ONLY public.otp_phone_number_change DROP CONSTRAINT IF EXISTS fkcrkpc89bex0nxf6aerucrlih3;
ALTER TABLE IF EXISTS ONLY public.vehicle_details DROP CONSTRAINT IF EXISTS fk9dxu2yfd1pt9nw2ckblmdk9hp;
ALTER TABLE IF EXISTS ONLY public.vehicle_model DROP CONSTRAINT IF EXISTS fk98llvh0lycy5d15beewtbcgvl;
ALTER TABLE IF EXISTS ONLY public.otp DROP CONSTRAINT IF EXISTS fk7r7o2j5hfi9r4evngsvpvfdue;
ALTER TABLE IF EXISTS ONLY public.user_details DROP CONSTRAINT IF EXISTS fk50y1t4e7shg944xrg67kpypjw;
ALTER TABLE IF EXISTS ONLY public.profile_video DROP CONSTRAINT IF EXISTS fk4rocu630fo1isp0b6lwxswwhk;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
ALTER TABLE IF EXISTS ONLY public.applied_coupon DROP CONSTRAINT IF EXISTS applied_coupon_user_id_23e0c117_fk_user_login_id;
DROP INDEX IF EXISTS public.service_request_vehicle_id_40144b75;
DROP INDEX IF EXISTS public.service_request_mechanic_id_2188b81f;
DROP INDEX IF EXISTS public.service_comment_service_request_id_e2867c1a;
DROP INDEX IF EXISTS public.order_user_id_e323497c;
DROP INDEX IF EXISTS public.order_product_id_5feb8b6f;
DROP INDEX IF EXISTS public.mechanic_user_id_2d21c908;
DROP INDEX IF EXISTS public.mechanic_mechanic_code_577860fa_like;
DROP INDEX IF EXISTS public.django_session_session_key_c0390e0f_like;
DROP INDEX IF EXISTS public.django_session_expire_date_a5c62663;
DROP INDEX IF EXISTS public.django_admin_log_user_id_c564eba6;
DROP INDEX IF EXISTS public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX IF EXISTS public.auth_user_username_6821ab7c_like;
DROP INDEX IF EXISTS public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX IF EXISTS public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX IF EXISTS public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX IF EXISTS public.auth_user_groups_group_id_97559544;
DROP INDEX IF EXISTS public.auth_permission_content_type_id_2f476e4b;
DROP INDEX IF EXISTS public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX IF EXISTS public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX IF EXISTS public.auth_group_name_a6ea08ec_like;
DROP INDEX IF EXISTS public.applied_coupon_user_id_23e0c117;
ALTER TABLE IF EXISTS ONLY public.vehicle_model DROP CONSTRAINT IF EXISTS vehicle_model_pkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_location DROP CONSTRAINT IF EXISTS vehicle_location_pkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_details DROP CONSTRAINT IF EXISTS vehicle_details_pkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_company DROP CONSTRAINT IF EXISTS vehicle_company_pkey;
ALTER TABLE IF EXISTS ONLY public.user_login DROP CONSTRAINT IF EXISTS user_login_pkey;
ALTER TABLE IF EXISTS ONLY public.user_details DROP CONSTRAINT IF EXISTS user_details_pkey;
ALTER TABLE IF EXISTS ONLY public.vehicle_details DROP CONSTRAINT IF EXISTS uk_mohuxqbs38kpgwpih46kbgue7;
ALTER TABLE IF EXISTS ONLY public.otp_token DROP CONSTRAINT IF EXISTS uk_k1uq3sq0o8g78kkvx60cf27sa;
ALTER TABLE IF EXISTS ONLY public.user_details DROP CONSTRAINT IF EXISTS uk_f4pdcamta635qqbhgcyqvrg7f;
ALTER TABLE IF EXISTS ONLY public.profile_video DROP CONSTRAINT IF EXISTS uk_dkq03ydrd960rt7i9kgqtrka5;
ALTER TABLE IF EXISTS ONLY public.otp DROP CONSTRAINT IF EXISTS uk_4mkxc1wpojj1vymcvurokktwm;
ALTER TABLE IF EXISTS ONLY public.otp_phone_number_change DROP CONSTRAINT IF EXISTS uk_1lmnw8y4rw558p55w4y9csth3;
ALTER TABLE IF EXISTS ONLY public.service_request DROP CONSTRAINT IF EXISTS service_request_pkey;
ALTER TABLE IF EXISTS ONLY public.service_comment DROP CONSTRAINT IF EXISTS service_comment_pkey;
ALTER TABLE IF EXISTS ONLY public.profile_video DROP CONSTRAINT IF EXISTS profile_video_pkey;
ALTER TABLE IF EXISTS ONLY public.product DROP CONSTRAINT IF EXISTS product_pkey;
ALTER TABLE IF EXISTS ONLY public.otp_token DROP CONSTRAINT IF EXISTS otp_token_pkey;
ALTER TABLE IF EXISTS ONLY public.otp DROP CONSTRAINT IF EXISTS otp_pkey;
ALTER TABLE IF EXISTS ONLY public.otp_phone_number_change DROP CONSTRAINT IF EXISTS otp_phone_number_change_pkey;
ALTER TABLE IF EXISTS ONLY public."order" DROP CONSTRAINT IF EXISTS order_pkey;
ALTER TABLE IF EXISTS ONLY public.mechanic DROP CONSTRAINT IF EXISTS mechanic_pkey;
ALTER TABLE IF EXISTS ONLY public.mechanic DROP CONSTRAINT IF EXISTS mechanic_mechanic_code_key;
ALTER TABLE IF EXISTS ONLY public.health_check_db_testmodel DROP CONSTRAINT IF EXISTS health_check_db_testmodel_pkey;
ALTER TABLE IF EXISTS ONLY public.django_session DROP CONSTRAINT IF EXISTS django_session_pkey;
ALTER TABLE IF EXISTS ONLY public.django_migrations DROP CONSTRAINT IF EXISTS django_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_username_key;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_name_key;
ALTER TABLE IF EXISTS ONLY public.applied_coupon DROP CONSTRAINT IF EXISTS applied_coupon_pkey;
SELECT pg_catalog.lo_unlink(oid) FROM pg_catalog.pg_largeobject_metadata WHERE oid = '16802';
SELECT pg_catalog.lo_unlink(oid) FROM pg_catalog.pg_largeobject_metadata WHERE oid = '16785';
SELECT pg_catalog.lo_unlink(oid) FROM pg_catalog.pg_largeobject_metadata WHERE oid = '16770';
SELECT pg_catalog.lo_unlink(oid) FROM pg_catalog.pg_largeobject_metadata WHERE oid = '16769';
SELECT pg_catalog.lo_unlink(oid) FROM pg_catalog.pg_largeobject_metadata WHERE oid = '16768';
DROP SEQUENCE IF EXISTS public.vehicle_model_seq;
DROP TABLE IF EXISTS public.vehicle_model;
DROP SEQUENCE IF EXISTS public.vehicle_location_seq;
DROP TABLE IF EXISTS public.vehicle_location;
DROP SEQUENCE IF EXISTS public.vehicle_details_seq;
DROP TABLE IF EXISTS public.vehicle_details;
DROP SEQUENCE IF EXISTS public.vehicle_company_seq;
DROP TABLE IF EXISTS public.vehicle_company;
DROP SEQUENCE IF EXISTS public.user_login_id_seq;
DROP TABLE IF EXISTS public.user_login;
DROP SEQUENCE IF EXISTS public.user_details_id_seq;
DROP TABLE IF EXISTS public.user_details;
DROP TABLE IF EXISTS public.service_request;
DROP TABLE IF EXISTS public.service_comment;
DROP SEQUENCE IF EXISTS public.profile_video_seq;
DROP TABLE IF EXISTS public.profile_video;
DROP TABLE IF EXISTS public.product;
DROP SEQUENCE IF EXISTS public.otp_token_seq;
DROP TABLE IF EXISTS public.otp_token;
DROP SEQUENCE IF EXISTS public.otp_seq;
DROP SEQUENCE IF EXISTS public.otp_phone_number_change_seq;
DROP TABLE IF EXISTS public.otp_phone_number_change;
DROP TABLE IF EXISTS public.otp;
DROP TABLE IF EXISTS public."order";
DROP TABLE IF EXISTS public.mechanic;
DROP TABLE IF EXISTS public.health_check_db_testmodel;
DROP TABLE IF EXISTS public.django_session;
DROP TABLE IF EXISTS public.django_migrations;
DROP TABLE IF EXISTS public.django_content_type;
DROP TABLE IF EXISTS public.django_admin_log;
DROP TABLE IF EXISTS public.auth_user_user_permissions;
DROP TABLE IF EXISTS public.auth_user_groups;
DROP TABLE IF EXISTS public.auth_user;
DROP TABLE IF EXISTS public.auth_permission;
DROP TABLE IF EXISTS public.auth_group_permissions;
DROP TABLE IF EXISTS public.auth_group;
DROP TABLE IF EXISTS public.applied_coupon;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: applied_coupon; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.applied_coupon (
    id integer NOT NULL,
    coupon_code character varying(255) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.applied_coupon OWNER TO admin;

--
-- Name: applied_coupon_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.applied_coupon ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.applied_coupon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO admin;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO admin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO admin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO admin;

--
-- Name: health_check_db_testmodel; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.health_check_db_testmodel (
    id integer NOT NULL,
    title character varying(128) NOT NULL
);


ALTER TABLE public.health_check_db_testmodel OWNER TO admin;

--
-- Name: health_check_db_testmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.health_check_db_testmodel ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.health_check_db_testmodel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: mechanic; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.mechanic (
    id integer NOT NULL,
    mechanic_code character varying(100) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.mechanic OWNER TO admin;

--
-- Name: mechanic_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.mechanic ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.mechanic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: order; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."order" (
    id integer NOT NULL,
    quantity integer NOT NULL,
    created_on timestamp with time zone NOT NULL,
    status character varying(20) NOT NULL,
    product_id integer NOT NULL,
    user_id integer NOT NULL,
    transaction_id character varying(255) NOT NULL
);


ALTER TABLE public."order" OWNER TO admin;

--
-- Name: order_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public."order" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: otp; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.otp (
    id bigint NOT NULL,
    count integer NOT NULL,
    otp character varying(255),
    status character varying(255),
    user_id bigint
);


ALTER TABLE public.otp OWNER TO admin;

--
-- Name: otp_phone_number_change; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.otp_phone_number_change (
    id bigint NOT NULL,
    new_phone character varying(255),
    old_phone character varying(255),
    otp character varying(255),
    status character varying(255),
    user_id bigint
);


ALTER TABLE public.otp_phone_number_change OWNER TO admin;

--
-- Name: otp_phone_number_change_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.otp_phone_number_change_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.otp_phone_number_change_seq OWNER TO admin;

--
-- Name: otp_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.otp_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.otp_seq OWNER TO admin;

--
-- Name: otp_token; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.otp_token (
    id bigint NOT NULL,
    email_token character varying(255),
    new_email character varying(255),
    old_email character varying(255),
    status character varying(255),
    user_id bigint
);


ALTER TABLE public.otp_token OWNER TO admin;

--
-- Name: otp_token_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.otp_token_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.otp_token_seq OWNER TO admin;

--
-- Name: product; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.product (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    price numeric(20,2) NOT NULL,
    image_url character varying(255) NOT NULL
);


ALTER TABLE public.product OWNER TO admin;

--
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: profile_video; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.profile_video (
    id bigint NOT NULL,
    conversion_params character varying(255),
    video oid,
    video_name character varying(255),
    user_id bigint
);


ALTER TABLE public.profile_video OWNER TO admin;

--
-- Name: profile_video_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.profile_video_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profile_video_seq OWNER TO admin;

--
-- Name: service_comment; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.service_comment (
    id integer NOT NULL,
    comment character varying(500) NOT NULL,
    created_on timestamp with time zone NOT NULL,
    service_request_id integer NOT NULL
);


ALTER TABLE public.service_comment OWNER TO admin;

--
-- Name: service_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.service_comment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.service_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: service_request; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.service_request (
    id integer NOT NULL,
    problem_details character varying(500) NOT NULL,
    created_on timestamp with time zone NOT NULL,
    updated_on timestamp with time zone,
    status character varying(10) NOT NULL,
    mechanic_id integer NOT NULL,
    vehicle_id integer NOT NULL
);


ALTER TABLE public.service_request OWNER TO admin;

--
-- Name: service_request_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.service_request ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.service_request_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_details; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.user_details (
    id bigint NOT NULL,
    available_credit double precision NOT NULL,
    name character varying(255),
    picture oid,
    status character varying(255),
    user_id bigint
);


ALTER TABLE public.user_details OWNER TO admin;

--
-- Name: user_details_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.user_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_details_id_seq OWNER TO admin;

--
-- Name: user_login; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.user_login (
    id bigint NOT NULL,
    api_key character varying(1000),
    code character varying(255),
    created_on date,
    email character varying(255),
    jwt_token character varying(500),
    number character varying(255),
    password character varying(255),
    role smallint,
    CONSTRAINT user_login_role_check CHECK (((role >= 0) AND (role <= 3)))
);


ALTER TABLE public.user_login OWNER TO admin;

--
-- Name: user_login_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.user_login_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_login_id_seq OWNER TO admin;

--
-- Name: vehicle_company; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.vehicle_company (
    id bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.vehicle_company OWNER TO admin;

--
-- Name: vehicle_company_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.vehicle_company_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehicle_company_seq OWNER TO admin;

--
-- Name: vehicle_details; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.vehicle_details (
    id bigint NOT NULL,
    pincode character varying(255),
    status smallint,
    uuid uuid NOT NULL,
    vin character varying(255),
    year bigint NOT NULL,
    vehicle_model_id bigint,
    owner_id bigint,
    location_id bigint,
    CONSTRAINT vehicle_details_status_check CHECK (((status >= 0) AND (status <= 8)))
);


ALTER TABLE public.vehicle_details OWNER TO admin;

--
-- Name: vehicle_details_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.vehicle_details_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehicle_details_seq OWNER TO admin;

--
-- Name: vehicle_location; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.vehicle_location (
    id bigint NOT NULL,
    latitude character varying(255),
    longitude character varying(255)
);


ALTER TABLE public.vehicle_location OWNER TO admin;

--
-- Name: vehicle_location_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.vehicle_location_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehicle_location_seq OWNER TO admin;

--
-- Name: vehicle_model; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.vehicle_model (
    id bigint NOT NULL,
    fuel_type smallint,
    model character varying(255),
    vehicle_img character varying(255),
    vehiclecompany_id bigint,
    CONSTRAINT vehicle_model_fuel_type_check CHECK (((fuel_type >= 0) AND (fuel_type <= 2)))
);


ALTER TABLE public.vehicle_model OWNER TO admin;

--
-- Name: vehicle_model_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.vehicle_model_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehicle_model_seq OWNER TO admin;

--
-- Name: 16768; Type: BLOB; Schema: -; Owner: admin
--

SELECT pg_catalog.lo_create('16768');


ALTER LARGE OBJECT 16768 OWNER TO admin;

--
-- Name: 16769; Type: BLOB; Schema: -; Owner: admin
--

SELECT pg_catalog.lo_create('16769');


ALTER LARGE OBJECT 16769 OWNER TO admin;

--
-- Name: 16770; Type: BLOB; Schema: -; Owner: admin
--

SELECT pg_catalog.lo_create('16770');


ALTER LARGE OBJECT 16770 OWNER TO admin;

--
-- Name: 16785; Type: BLOB; Schema: -; Owner: admin
--

SELECT pg_catalog.lo_create('16785');


ALTER LARGE OBJECT 16785 OWNER TO admin;

--
-- Name: 16802; Type: BLOB; Schema: -; Owner: admin
--

SELECT pg_catalog.lo_create('16802');


ALTER LARGE OBJECT 16802 OWNER TO admin;

--
-- Data for Name: applied_coupon; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.applied_coupon (id, coupon_code, user_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add test model	7	add_testmodel
26	Can change test model	7	change_testmodel
27	Can delete test model	7	delete_testmodel
28	Can view test model	7	view_testmodel
29	Can add user	8	add_user
30	Can change user	8	change_user
31	Can delete user	8	delete_user
32	Can view user	8	view_user
33	Can add vehicle company	9	add_vehiclecompany
34	Can change vehicle company	9	change_vehiclecompany
35	Can delete vehicle company	9	delete_vehiclecompany
36	Can view vehicle company	9	view_vehiclecompany
37	Can add vehicle model	10	add_vehiclemodel
38	Can change vehicle model	10	change_vehiclemodel
39	Can delete vehicle model	10	delete_vehiclemodel
40	Can view vehicle model	10	view_vehiclemodel
41	Can add vehicle	11	add_vehicle
42	Can change vehicle	11	change_vehicle
43	Can delete vehicle	11	delete_vehicle
44	Can view vehicle	11	view_vehicle
45	Can add user details	12	add_userdetails
46	Can change user details	12	change_userdetails
47	Can delete user details	12	delete_userdetails
48	Can view user details	12	view_userdetails
49	Can add mechanic	13	add_mechanic
50	Can change mechanic	13	change_mechanic
51	Can delete mechanic	13	delete_mechanic
52	Can view mechanic	13	view_mechanic
53	Can add product	14	add_product
54	Can change product	14	change_product
55	Can delete product	14	delete_product
56	Can view product	14	view_product
57	Can add service request	15	add_servicerequest
58	Can change service request	15	change_servicerequest
59	Can delete service request	15	delete_servicerequest
60	Can view service request	15	view_servicerequest
61	Can add order	16	add_order
62	Can change order	16	change_order
63	Can delete order	16	delete_order
64	Can view order	16	view_order
65	Can add applied coupon	17	add_appliedcoupon
66	Can change applied coupon	17	change_appliedcoupon
67	Can delete applied coupon	17	delete_appliedcoupon
68	Can view applied coupon	17	view_appliedcoupon
69	Can add coupon	18	add_coupon
70	Can change coupon	18	change_coupon
71	Can delete coupon	18	delete_coupon
72	Can view coupon	18	view_coupon
73	Can add service comment	19	add_servicecomment
74	Can change service comment	19	change_servicecomment
75	Can delete service comment	19	delete_servicecomment
76	Can view service comment	19	view_servicecomment
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	db	testmodel
8	crapi	user
9	crapi	vehiclecompany
10	crapi	vehiclemodel
11	crapi	vehicle
12	crapi	userdetails
13	crapi	mechanic
14	crapi	product
15	crapi	servicerequest
16	crapi	order
17	crapi	appliedcoupon
18	crapi	coupon
19	crapi	servicecomment
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2026-09-18 15:30:04.080699+00
2	auth	0001_initial	2026-09-18 15:30:10.345193+00
3	admin	0001_initial	2026-09-18 15:30:14.435561+00
4	admin	0002_logentry_remove_auto_add	2026-09-18 15:30:15.455303+00
5	admin	0003_logentry_add_action_flag_choices	2026-09-18 15:30:16.940413+00
6	contenttypes	0002_remove_content_type_name	2026-09-18 15:30:19.118486+00
7	auth	0002_alter_permission_name_max_length	2026-09-18 15:30:20.35526+00
8	auth	0003_alter_user_email_max_length	2026-09-18 15:30:20.965919+00
9	auth	0004_alter_user_username_opts	2026-09-18 15:30:22.000554+00
10	auth	0005_alter_user_last_login_null	2026-09-18 15:30:23.350403+00
11	auth	0006_require_contenttypes_0002	2026-09-18 15:30:24.145634+00
12	auth	0007_alter_validators_add_error_messages	2026-09-18 15:30:24.925717+00
13	auth	0008_alter_user_username_max_length	2026-09-18 15:30:26.100585+00
14	auth	0009_alter_user_last_name_max_length	2026-09-18 15:30:27.125263+00
15	auth	0010_alter_group_name_max_length	2026-09-18 15:30:27.692361+00
16	auth	0011_update_proxy_permissions	2026-09-18 15:30:28.213625+00
17	auth	0012_alter_user_first_name_max_length	2026-09-18 15:30:29.083382+00
18	crapi	0001_initial	2026-09-18 15:31:37.280496+00
19	crapi	0002_order_transaction_id	2026-09-18 15:31:37.715694+00
20	crapi	0003_alter_appliedcoupon_id_alter_mechanic_id_and_more	2026-09-18 15:31:38.085426+00
21	crapi	0004_alter_servicerequest_status_servicecomment	2026-09-18 15:31:38.795619+00
22	health_check_db	0001_initial	2026-09-18 15:31:39.145662+00
23	sessions	0001_initial	2026-09-18 15:31:39.885468+00
24	db	0001_initial	2026-09-18 15:31:40.25598+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: health_check_db_testmodel; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.health_check_db_testmodel (id, title) FROM stdin;
\.


--
-- Data for Name: mechanic; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.mechanic (id, mechanic_code, user_id) FROM stdin;
1	TRAC_JHN	6
2	TRAC_JME	7
\.


--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public."order" (id, quantity, created_on, status, product_id, user_id, transaction_id) FROM stdin;
1	2	2026-09-18 15:31:56.935217+00	delivered	1	1	79ff4c5c-4803-4b55-9f81-7fec15af95ac
2	2	2026-09-18 15:31:57.190237+00	delivered	1	2	56b19df6-dc04-4979-9ac6-04af4f388d7f
3	2	2026-09-18 15:31:57.460167+00	delivered	1	3	01ad6fa1-75cb-4f36-b0b5-11c125daa41e
4	2	2026-09-18 15:31:57.740511+00	delivered	1	4	02f41b73-aabd-43f7-9737-a99a74770691
5	2	2026-09-18 15:31:57.999607+00	delivered	1	5	e455396a-7fb0-4ca5-abf5-e439e98bbac7
\.


--
-- Data for Name: otp; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.otp (id, count, otp, status, user_id) FROM stdin;
\.


--
-- Data for Name: otp_phone_number_change; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.otp_phone_number_change (id, new_phone, old_phone, otp, status, user_id) FROM stdin;
\.


--
-- Data for Name: otp_token; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.otp_token (id, email_token, new_email, old_email, status, user_id) FROM stdin;
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.product (id, name, price, image_url) FROM stdin;
1	Seat	10.00	images/seat.svg
2	Wheel	10.00	images/wheel.svg
\.


--
-- Data for Name: profile_video; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.profile_video (id, conversion_params, video, video_name, user_id) FROM stdin;
1	-v codec h264	16768	Adam_video	1
2	-v codec h264	16769	Pogba_video	2
3	-v codec h264	16770	Robot_video	3
4	-v codec h264	16785	Test_video	4
5	-v codec h264	16802	Admin_video	5
\.


--
-- Data for Name: service_comment; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.service_comment (id, comment, created_on, service_request_id) FROM stdin;
\.


--
-- Data for Name: service_request; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.service_request (id, problem_details, created_on, updated_on, status, mechanic_id, vehicle_id) FROM stdin;
1	My car Hyundai - Creta is having issues.\nCan you give me a call on my mobile 9876895423,\nOr send me an email at adam007@example.com\nThanks,\nAdam.\n	2026-09-18 15:31:55.162431+00	\N	inprogress	1	1
2	My car Hyundai - Creta is having issues.\nCan you give me a call on my mobile 9876895423,\nOr send me an email at adam007@example.com\nThanks,\nAdam.\n	2026-09-18 15:31:55.425555+00	\N	pending	2	1
3	My car Audi - RS7 is having issues.\nCan you give me a call on my mobile 9010203040,\nOr send me an email at admin@example.com\nThanks,\nAdmin.\n	2026-09-18 15:31:55.950312+00	\N	inprogress	2	5
4	My car Audi - RS7 is having issues.\nCan you give me a call on my mobile 9010203040,\nOr send me an email at admin@example.com\nThanks,\nAdmin.\n	2026-09-18 15:31:56.218899+00	\N	completed	1	5
5	My car Audi - RS7 is having issues.\nCan you give me a call on my mobile 9010203040,\nOr send me an email at admin@example.com\nThanks,\nAdmin.\n	2026-09-18 15:31:56.49283+00	\N	pending	1	5
\.


--
-- Data for Name: user_details; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.user_details (id, available_credit, name, picture, status, user_id) FROM stdin;
1	100	Adam	\N	ACTIVE	1
2	100	Pogba	\N	ACTIVE	2
3	100	Robot	\N	ACTIVE	3
4	100	Test	\N	ACTIVE	4
5	100	Admin	\N	ACTIVE	5
6	0	Jhon	\N	ACTIVE	6
7	0	James	\N	ACTIVE	7
8	100	Testuser01	\N	ACTIVE	8
9	100	Testuser02	\N	ACTIVE	9
10	100	Merchant01	\N	ACTIVE	10
11	100	Analyst01	\N	ACTIVE	11
12	100	Demoadmin	\N	ACTIVE	12
\.


--
-- Data for Name: user_login; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.user_login (id, api_key, code, created_on, email, jwt_token, number, password, role) FROM stdin;
6	\N	\N	2026-09-18	jhon@example.com	\N		$2b$12$FKj5Og9GRHuz621RUZQ9weWdNRrYSkh7pnk6XMkwEvdUSPHmRMLHq	2
7	\N	\N	2026-09-18	james@example.com	\N		$2b$12$uB/xaVPmL087GSN1FgPUL.kzULs0v1oj34/JqOKSJmuwxopHWf8Qm	2
8	\N		2026-09-18	testuser01@ztlab.local	\N	9000000000	$2a$10$E/flHyPYCG1dLoaELrbi6u55BVoGVk3TNNnQMnhBdO98pgOzKs67y	1
9	\N		2026-09-18	testuser02@ztlab.local	\N	9000000001	$2a$10$pGaweKCCmst0OAKhyqeixex8zbvmW5ssnOksLPeWHhu0C6M0HrWrK	1
10	\N		2026-09-18	merchant01@ztlab.local	\N	9000000002	$2a$10$sC1hOV6Ouf8rbFhRSzIdcOscVcqYoKaD4Mg6.Ldny/W19LUESr9lm	1
11	\N		2026-09-18	analyst01@ztlab.local	\N	9000000003	$2a$10$V2NgNOMnohx6LvBEnCd8Vu8Qf/QDnRwEQGqzXX8lxATLhMnbJo0Zu	1
12	\N		2026-09-18	demoadmin@ztlab.local	\N	9000000004	$2a$10$FJd9QYMMADUxdfJMhhjwxeoZ1ERbEO3Q8/K.i4oRcw.cwq6uwa0XK	1
1	\N		2026-09-18	adam007@example.com	\N	9876895423	$2a$10$VVN9K51x7zkqwWZqdTS39uYlSqg6aa9Id7j51tv.YrISpHktKazVW	0
2	\N		2026-09-18	pogba006@example.com	\N	9876570006	$2a$10$DU0Teo3a0O1HpY0kjRJDo.We2fhQhn132Gi0iFg4g0g4oF0AR4Jny	0
3	\N		2026-09-18	robot001@example.com	\N	9876570001	$2a$10$R9lAkumFxjTqwqRxc7B9IuBypWkzVRZy3Ru8C2NkI9IOONFEZBSVe	0
4	\N		2026-09-18	test@example.com	\N	9876540001	$2a$10$MwV9HMEunwRmLqWl.V4n3eHTAVxXZo0oTgbuDwWlxjWNB3K9jN87a	1
5	\N		2026-09-18	admin@example.com	\N	9010203040	$2a$10$4gdMY/wWAbGdGpHi2JDcYe.xUp8wFk5iL6TuDkfe9S/rfrd743Fc6	3
\.


--
-- Data for Name: vehicle_company; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.vehicle_company (id, name) FROM stdin;
1	Hyundai
2	Lamborghini
3	Mercedes-Benz
4	BMW
5	Audi
6	MG Motor
\.


--
-- Data for Name: vehicle_details; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.vehicle_details (id, pincode, status, uuid, vin, year, vehicle_model_id, owner_id, location_id) FROM stdin;
1	123456	1	f89b5f21-7829-45cb-a650-299a61090378	7ECOX34KJTV359804	2026	1	1	1
2	123456	1	cd515c12-0fc1-48ae-8b61-9230b70a845b	8VAUI03PRUQ686911	2026	6	2	2
3	123456	1	4bae9968-ec7f-4de3-a3a0-ba1b2ab5e5e5	0NKPZ09IHOP508673	2026	4	3	3
4	123456	1	1929186d-8b67-4163-a208-de52a41f7301	8IGEF39BZUJ159285	2026	6	4	4
5	123456	1	f5c506f5-3af2-4120-926c-64ad8b10ddc2	6NBBY70FWUM324316	2026	5	5	5
52	5528	1	914aa36c-5c36-4548-8164-ef17dc5ea1fd	4X9V2C157703EF0DC	2026	6	\N	5
53	1708	1	df8a14b4-ffa8-47c8-85c8-bb464b8d493b	RF2C02MFW0015V42T	2026	4	\N	1
54	9485	1	690f9511-d21b-4462-9f68-ff0b15151bf1	A865363H0Y80SH177	2026	3	\N	5
55	9344	1	5ef45678-95dc-4122-9d70-2849f4f783c8	M6975N21W2X1VY88H	2026	4	\N	1
56	6650	1	1eca83a7-5c75-468b-ac52-75e590fa2796	2Y2A3J58E3V214M64	2026	4	\N	2
\.


--
-- Data for Name: vehicle_location; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.vehicle_location (id, latitude, longitude) FROM stdin;
1	32.778889	-91.919243
2	31.284788	-92.471176
3	37.746880	-84.301460
4	38.206348	-84.270172
5	37.406769	-94.705528
\.


--
-- Data for Name: vehicle_model; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.vehicle_model (id, fuel_type, model, vehicle_img, vehiclecompany_id) FROM stdin;
1	2	Creta	images/hyundai-creta.jpg	1
2	1	Aventador	images/lamborghini-aventador.jpg	2
3	1	GLA Class	images/mercedesbenz-gla.jpg	3
4	1	5 Series	images/bmw-5.jpg	4
5	1	RS7	images/audi-rs7.jpg	5
6	1	Hector Plus	images/mgmotor-hectorplus.jpg	6
\.


--
-- Name: applied_coupon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.applied_coupon_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 76, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, false);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 19, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 24, true);


--
-- Name: health_check_db_testmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.health_check_db_testmodel_id_seq', 5, true);


--
-- Name: mechanic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.mechanic_id_seq', 2, true);


--
-- Name: order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.order_id_seq', 5, true);


--
-- Name: otp_phone_number_change_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.otp_phone_number_change_seq', 1, false);


--
-- Name: otp_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.otp_seq', 1, false);


--
-- Name: otp_token_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.otp_token_seq', 1, false);


--
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.product_id_seq', 2, true);


--
-- Name: profile_video_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.profile_video_seq', 51, true);


--
-- Name: service_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.service_comment_id_seq', 1, false);


--
-- Name: service_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.service_request_id_seq', 5, true);


--
-- Name: user_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.user_details_id_seq', 12, true);


--
-- Name: user_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.user_login_id_seq', 12, true);


--
-- Name: vehicle_company_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.vehicle_company_seq', 51, true);


--
-- Name: vehicle_details_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.vehicle_details_seq', 101, true);


--
-- Name: vehicle_location_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.vehicle_location_seq', 51, true);


--
-- Name: vehicle_model_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.vehicle_model_seq', 51, true);


--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: -
--

BEGIN;

SELECT pg_catalog.lo_open('16768', 131072);
SELECT pg_catalog.lowrite(0, '\x3851d9d47acb933dbe70');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('16769', 131072);
SELECT pg_catalog.lowrite(0, '\x3af01d4fb770e98c0325');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('16770', 131072);
SELECT pg_catalog.lowrite(0, '\x6da712c82bcd4d554bf0');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('16785', 131072);
SELECT pg_catalog.lowrite(0, '\x4de9ef9c2f931efc580f');
SELECT pg_catalog.lo_close(0);

SELECT pg_catalog.lo_open('16802', 131072);
SELECT pg_catalog.lowrite(0, '\x07b1e805f2b4f5f0f1d0');
SELECT pg_catalog.lo_close(0);

COMMIT;

--
-- Name: applied_coupon applied_coupon_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.applied_coupon
    ADD CONSTRAINT applied_coupon_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: health_check_db_testmodel health_check_db_testmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.health_check_db_testmodel
    ADD CONSTRAINT health_check_db_testmodel_pkey PRIMARY KEY (id);


--
-- Name: mechanic mechanic_mechanic_code_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.mechanic
    ADD CONSTRAINT mechanic_mechanic_code_key UNIQUE (mechanic_code);


--
-- Name: mechanic mechanic_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.mechanic
    ADD CONSTRAINT mechanic_pkey PRIMARY KEY (id);


--
-- Name: order order_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_pkey PRIMARY KEY (id);


--
-- Name: otp_phone_number_change otp_phone_number_change_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp_phone_number_change
    ADD CONSTRAINT otp_phone_number_change_pkey PRIMARY KEY (id);


--
-- Name: otp otp_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp
    ADD CONSTRAINT otp_pkey PRIMARY KEY (id);


--
-- Name: otp_token otp_token_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp_token
    ADD CONSTRAINT otp_token_pkey PRIMARY KEY (id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: profile_video profile_video_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.profile_video
    ADD CONSTRAINT profile_video_pkey PRIMARY KEY (id);


--
-- Name: service_comment service_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.service_comment
    ADD CONSTRAINT service_comment_pkey PRIMARY KEY (id);


--
-- Name: service_request service_request_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.service_request
    ADD CONSTRAINT service_request_pkey PRIMARY KEY (id);


--
-- Name: otp_phone_number_change uk_1lmnw8y4rw558p55w4y9csth3; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp_phone_number_change
    ADD CONSTRAINT uk_1lmnw8y4rw558p55w4y9csth3 UNIQUE (user_id);


--
-- Name: otp uk_4mkxc1wpojj1vymcvurokktwm; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp
    ADD CONSTRAINT uk_4mkxc1wpojj1vymcvurokktwm UNIQUE (user_id);


--
-- Name: profile_video uk_dkq03ydrd960rt7i9kgqtrka5; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.profile_video
    ADD CONSTRAINT uk_dkq03ydrd960rt7i9kgqtrka5 UNIQUE (user_id);


--
-- Name: user_details uk_f4pdcamta635qqbhgcyqvrg7f; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT uk_f4pdcamta635qqbhgcyqvrg7f UNIQUE (user_id);


--
-- Name: otp_token uk_k1uq3sq0o8g78kkvx60cf27sa; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp_token
    ADD CONSTRAINT uk_k1uq3sq0o8g78kkvx60cf27sa UNIQUE (user_id);


--
-- Name: vehicle_details uk_mohuxqbs38kpgwpih46kbgue7; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehicle_details
    ADD CONSTRAINT uk_mohuxqbs38kpgwpih46kbgue7 UNIQUE (uuid);


--
-- Name: user_details user_details_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT user_details_pkey PRIMARY KEY (id);


--
-- Name: user_login user_login_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_login
    ADD CONSTRAINT user_login_pkey PRIMARY KEY (id);


--
-- Name: vehicle_company vehicle_company_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehicle_company
    ADD CONSTRAINT vehicle_company_pkey PRIMARY KEY (id);


--
-- Name: vehicle_details vehicle_details_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehicle_details
    ADD CONSTRAINT vehicle_details_pkey PRIMARY KEY (id);


--
-- Name: vehicle_location vehicle_location_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehicle_location
    ADD CONSTRAINT vehicle_location_pkey PRIMARY KEY (id);


--
-- Name: vehicle_model vehicle_model_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehicle_model
    ADD CONSTRAINT vehicle_model_pkey PRIMARY KEY (id);


--
-- Name: applied_coupon_user_id_23e0c117; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX applied_coupon_user_id_23e0c117 ON public.applied_coupon USING btree (user_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: mechanic_mechanic_code_577860fa_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX mechanic_mechanic_code_577860fa_like ON public.mechanic USING btree (mechanic_code varchar_pattern_ops);


--
-- Name: mechanic_user_id_2d21c908; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX mechanic_user_id_2d21c908 ON public.mechanic USING btree (user_id);


--
-- Name: order_product_id_5feb8b6f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX order_product_id_5feb8b6f ON public."order" USING btree (product_id);


--
-- Name: order_user_id_e323497c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX order_user_id_e323497c ON public."order" USING btree (user_id);


--
-- Name: service_comment_service_request_id_e2867c1a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX service_comment_service_request_id_e2867c1a ON public.service_comment USING btree (service_request_id);


--
-- Name: service_request_mechanic_id_2188b81f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX service_request_mechanic_id_2188b81f ON public.service_request USING btree (mechanic_id);


--
-- Name: service_request_vehicle_id_40144b75; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX service_request_vehicle_id_40144b75 ON public.service_request USING btree (vehicle_id);


--
-- Name: applied_coupon applied_coupon_user_id_23e0c117_fk_user_login_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.applied_coupon
    ADD CONSTRAINT applied_coupon_user_id_23e0c117_fk_user_login_id FOREIGN KEY (user_id) REFERENCES public.user_login(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: profile_video fk4rocu630fo1isp0b6lwxswwhk; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.profile_video
    ADD CONSTRAINT fk4rocu630fo1isp0b6lwxswwhk FOREIGN KEY (user_id) REFERENCES public.user_login(id);


--
-- Name: user_details fk50y1t4e7shg944xrg67kpypjw; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT fk50y1t4e7shg944xrg67kpypjw FOREIGN KEY (user_id) REFERENCES public.user_login(id);


--
-- Name: otp fk7r7o2j5hfi9r4evngsvpvfdue; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp
    ADD CONSTRAINT fk7r7o2j5hfi9r4evngsvpvfdue FOREIGN KEY (user_id) REFERENCES public.user_login(id);


--
-- Name: vehicle_model fk98llvh0lycy5d15beewtbcgvl; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehicle_model
    ADD CONSTRAINT fk98llvh0lycy5d15beewtbcgvl FOREIGN KEY (vehiclecompany_id) REFERENCES public.vehicle_company(id);


--
-- Name: vehicle_details fk9dxu2yfd1pt9nw2ckblmdk9hp; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehicle_details
    ADD CONSTRAINT fk9dxu2yfd1pt9nw2ckblmdk9hp FOREIGN KEY (location_id) REFERENCES public.vehicle_location(id);


--
-- Name: otp_phone_number_change fkcrkpc89bex0nxf6aerucrlih3; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp_phone_number_change
    ADD CONSTRAINT fkcrkpc89bex0nxf6aerucrlih3 FOREIGN KEY (user_id) REFERENCES public.user_login(id);


--
-- Name: otp_token fkfg4vifvm6fphhv4o1r9vkj7k4; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.otp_token
    ADD CONSTRAINT fkfg4vifvm6fphhv4o1r9vkj7k4 FOREIGN KEY (user_id) REFERENCES public.user_login(id);


--
-- Name: vehicle_details fkhddm1k427ctferv7q18yw8g2l; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehicle_details
    ADD CONSTRAINT fkhddm1k427ctferv7q18yw8g2l FOREIGN KEY (owner_id) REFERENCES public.user_login(id);


--
-- Name: vehicle_details fko56hs6spaqghjao74nxo722d9; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vehicle_details
    ADD CONSTRAINT fko56hs6spaqghjao74nxo722d9 FOREIGN KEY (vehicle_model_id) REFERENCES public.vehicle_model(id);


--
-- Name: mechanic mechanic_user_id_2d21c908_fk_user_login_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.mechanic
    ADD CONSTRAINT mechanic_user_id_2d21c908_fk_user_login_id FOREIGN KEY (user_id) REFERENCES public.user_login(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order order_product_id_5feb8b6f_fk_product_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_product_id_5feb8b6f_fk_product_id FOREIGN KEY (product_id) REFERENCES public.product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: order order_user_id_e323497c_fk_user_login_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_user_id_e323497c_fk_user_login_id FOREIGN KEY (user_id) REFERENCES public.user_login(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_comment service_comment_service_request_id_e2867c1a_fk_service_r; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.service_comment
    ADD CONSTRAINT service_comment_service_request_id_e2867c1a_fk_service_r FOREIGN KEY (service_request_id) REFERENCES public.service_request(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_request service_request_mechanic_id_2188b81f_fk_mechanic_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.service_request
    ADD CONSTRAINT service_request_mechanic_id_2188b81f_fk_mechanic_id FOREIGN KEY (mechanic_id) REFERENCES public.mechanic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_request service_request_vehicle_id_40144b75_fk_vehicle_details_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.service_request
    ADD CONSTRAINT service_request_vehicle_id_40144b75_fk_vehicle_details_id FOREIGN KEY (vehicle_id) REFERENCES public.vehicle_details(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict Cla6iqfacnsQy1dZ2XwsUlbZwp2fXmf8MlgNQMUE314pxYHGJlEDHHf8eMKbupQ

